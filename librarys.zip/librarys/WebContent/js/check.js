// JavaScript Document
var check=function(){
	window.location.href="text.html";
}
