// JavaScript Document
var loginA=function(){
	window.location.href="index.html";
}
