package dao;
import domain.SystemManager;

public interface systemManangerDao {

	void update(SystemManager systemManager);
	
	SystemManager findSystemManager();
}
