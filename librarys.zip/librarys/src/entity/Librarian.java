/**
 * 
 */
package entity;

/**
 * @author Administrator
 *
 */
public class Librarian {

	

	private Librarian()
	{
		
	}
}
